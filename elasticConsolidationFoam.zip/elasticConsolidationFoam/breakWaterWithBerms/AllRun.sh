#!/bin/bash

blockMesh >blockMesh.log
echo blockMesh completed

cp -r 0.orig 0
 
decomposePar >decomposePar.log
echo decomposePar completed

mpirun -np 16 elasticConsolidationFoam -parallel &>TEST_C1_cons.log &




